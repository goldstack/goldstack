"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// dist/src/utils/routing/lambda.js
var lambda_exports = {};
__export(lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lambda_exports);

// dist/src/utils/routing/routes-manifest.json
var routes_manifest_default = {
  version: 3,
  pages404: true,
  basePath: "",
  redirects: [
    {
      source: "/:path+/",
      destination: "/:path+",
      internal: true,
      statusCode: 308,
      regex: "^(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))/$"
    }
  ],
  headers: [],
  dynamicRoutes: [
    {
      page: "/404",
      regex: "^\\/404$"
    },
    {
      page: "/build_legacy",
      regex: "^\\/build_legacy$"
    },
    {
      page: "/build",
      regex: "^\\/build$"
    },
    {
      page: "/index",
      regex: "^\\/index$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/configure/[step]",
      regex: "^\\/projects\\/[id]\\/packages\\/[packageId]\\/configure\\/[step]$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/download",
      regex: "^\\/projects\\/[id]\\/packages\\/[packageId]\\/download$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/get-template",
      regex: "^\\/projects\\/[id]\\/packages\\/[packageId]\\/get-template$"
    },
    {
      page: "/templates/dynamodb",
      regex: "^\\/templates\\/dynamodb$"
    },
    {
      page: "/templates/express-lambda",
      regex: "^\\/templates\\/express-lambda$"
    },
    {
      page: "/templates/express-ses",
      regex: "^\\/templates\\/express-ses$"
    },
    {
      page: "/templates/go-gin",
      regex: "^\\/templates\\/go-gin$"
    },
    {
      page: "/templates/lambda-api",
      regex: "^\\/templates\\/lambda-api$"
    },
    {
      page: "/templates/nextjs-bootstrap",
      regex: "^\\/templates\\/nextjs-bootstrap$"
    },
    {
      page: "/templates/nextjs",
      regex: "^\\/templates\\/nextjs$"
    },
    {
      page: "/templates/s3",
      regex: "^\\/templates\\/s3$"
    },
    {
      page: "/templates/server-side-rendering",
      regex: "^\\/templates\\/server-side-rendering$"
    },
    {
      page: "/templates/serverless-api",
      regex: "^\\/templates\\/serverless-api$"
    },
    {
      page: "/templates/ses",
      regex: "^\\/templates\\/ses$"
    },
    {
      page: "/templates/static-website",
      regex: "^\\/templates\\/static-website$"
    },
    {
      page: "/templates/user-management",
      regex: "^\\/templates\\/user-management$"
    },
    {
      page: "/terms-and-conditions",
      regex: "^\\/terms-and-conditions$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/configure/[step]",
      regex: "^/projects/([^/]+?)/packages/([^/]+?)/configure/([^/]+?)(?:/)?$",
      routeKeys: {
        id: "id",
        packageId: "packageId",
        step: "step"
      },
      namedRegex: "^/projects/(?<id>[^/]+?)/packages/(?<packageId>[^/]+?)/configure/(?<step>[^/]+?)(?:/)?$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/download",
      regex: "^/projects/([^/]+?)/packages/([^/]+?)/download(?:/)?$",
      routeKeys: {
        id: "id",
        packageId: "packageId"
      },
      namedRegex: "^/projects/(?<id>[^/]+?)/packages/(?<packageId>[^/]+?)/download(?:/)?$"
    },
    {
      page: "/projects/[id]/packages/[packageId]/get-template",
      regex: "^/projects/([^/]+?)/packages/([^/]+?)/get\\-template(?:/)?$",
      routeKeys: {
        id: "id",
        packageId: "packageId"
      },
      namedRegex: "^/projects/(?<id>[^/]+?)/packages/(?<packageId>[^/]+?)/get\\-template(?:/)?$"
    },
    {
      page: "/templates/[template]",
      regex: "^/templates/([^/]+?)(?:/)?$",
      routeKeys: {
        template: "template"
      },
      namedRegex: "^/templates/(?<template>[^/]+?)(?:/)?$"
    }
  ],
  staticRoutes: [
    {
      page: "/",
      regex: "^/(?:/)?$",
      routeKeys: {},
      namedRegex: "^/(?:/)?$"
    },
    {
      page: "/build",
      regex: "^/build(?:/)?$",
      routeKeys: {},
      namedRegex: "^/build(?:/)?$"
    },
    {
      page: "/build_legacy",
      regex: "^/build_legacy(?:/)?$",
      routeKeys: {},
      namedRegex: "^/build_legacy(?:/)?$"
    },
    {
      page: "/terms-and-conditions",
      regex: "^/terms\\-and\\-conditions(?:/)?$",
      routeKeys: {},
      namedRegex: "^/terms\\-and\\-conditions(?:/)?$"
    }
  ],
  dataRoutes: [
    {
      page: "/templates/[template]",
      routeKeys: {
        template: "template"
      },
      dataRouteRegex: "^/_next/data/oIGUSC8uXRFv9HR1uPbKz/templates/([^/]+?)\\.json$",
      namedDataRouteRegex: "^/_next/data/oIGUSC8uXRFv9HR1uPbKz/templates/(?<template>[^/]+?)\\.json$"
    }
  ],
  rsc: {
    header: "RSC",
    varyHeader: "RSC, Next-Router-State-Tree, Next-Router-Prefetch"
  },
  rewrites: []
};

// dist/src/utils/routing/lambda.js
var handler = (event, context, callback) => {
  const request = event.Records[0].cf.request;
  const dynamicRoutes = routes_manifest_default.dynamicRoutes;
  const extension = request.uri.indexOf(".") !== -1 ? request.uri.split(".").pop() : ".html";
  for (const route of dynamicRoutes) {
    if (new RegExp(route.regex).test(request.uri)) {
      request.uri = route.page + extension;
      break;
    }
  }
  if (request.uri.indexOf(extension) === -1) {
    request.uri = request.uri + extension;
  }
  callback(null, request);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
